"""Load Kinect take metadata, image sequences, and rebuild CloudData geometry."""

from __future__ import annotations

import json
from pathlib import Path

import bpy

from . import default_render, scene_setup

IMAGE_DEPTH = "kinect_depth_seq"
IMAGE_COLOR = "kinect_color_seq"
ATTR_DEPTH_MM = "depth_mm"

# ImageUser holds frame_start / frame_current in Blender 4.2 (not on Image).
_image_users: dict[str, bpy.types.ImageUser] = {}
_sequence_first_paths: dict[str, str] = {}


def clear_sequence_cache() -> None:
    _image_users.clear()
    _sequence_first_paths.clear()


def _take_path(settings) -> Path | None:
    raw = bpy.path.abspath(settings.take_path).strip()
    if not raw:
        return None
    return Path(raw)


def read_take_metadata(take_dir: Path) -> dict:
    calib_path = take_dir / "calibration.json"
    manifest_path = take_dir / "manifest.json"
    if not calib_path.is_file():
        raise FileNotFoundError(f"Missing {calib_path.name}")
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Missing {manifest_path.name}")

    with calib_path.open(encoding="utf-8") as f:
        calibration = json.load(f)
    with manifest_path.open(encoding="utf-8") as f:
        manifest = json.load(f)

    depth_dir = take_dir / "depth_aligned"
    color_dir = take_dir / "color"
    if not depth_dir.is_dir():
        raise FileNotFoundError("Missing depth_aligned/ folder")
    if not color_dir.is_dir():
        raise FileNotFoundError("Missing color/ folder")

    return {
        "calibration": calibration,
        "manifest": manifest,
        "depth_dir": depth_dir,
        "color_dir": color_dir,
    }


def scaled_intrinsics(color_calib: dict, width: int, height: int, width_scale: float) -> dict:
    fx = float(color_calib["fx"])
    fy = float(color_calib["fy"])
    cx = float(color_calib["cx"])
    cy = float(color_calib["cy"])

    scale = width / (cx * 2.0)
    fx_s = fx * scale / width_scale
    fy_s = fy * scale
    cx_s = cx * scale
    cy_s = cy * scale

    return {"fx": fx_s, "fy": fy_s, "cx": cx_s, "cy": cy_s, "width": width, "height": height}


def _frame_paths(meta: dict, frame: int) -> tuple[Path, Path]:
    depth_path = meta["depth_dir"] / f"frame_{frame:06d}.exr"
    color_path = meta["color_dir"] / f"frame_{frame:06d}.png"
    if not depth_path.is_file():
        raise FileNotFoundError(f"Missing {depth_path.name}")
    if not color_path.is_file():
        raise FileNotFoundError(f"Missing {color_path.name}")
    return depth_path, color_path


def validate_take_frames(meta: dict) -> None:
    """Ensure first-frame files exist (called on Load Take)."""
    _frame_paths(meta, 1)


def _get_image_user(name: str, frame_count: int) -> bpy.types.ImageUser:
    user = _image_users.get(name)
    if user is None:
        user = bpy.types.ImageUser()
        user.frame_start = 1
        user.frame_offset = 0
        user.frame_duration = frame_count
        user.use_auto_refresh = True
        _image_users[name] = user
    else:
        user.frame_duration = frame_count
    return user


def _ensure_sequence_image(name: str, first_frame_path: Path) -> bpy.types.Image:
    """Register a native Blender image sequence (loads frame_000001, auto-detects siblings)."""
    filepath = str(first_frame_path)
    first_abs = bpy.path.abspath(filepath)

    img = bpy.data.images.get(name)
    if img is None:
        img = bpy.data.images.load(filepath, check_existing=False)
        img.name = name
    else:
        img.filepath = filepath

    img.source = "SEQUENCE"
    _sequence_first_paths[name] = first_abs
    return img


def setup_sequence_images(meta: dict) -> tuple[bpy.types.Image, bpy.types.Image]:
    depth_first = meta["depth_dir"] / "frame_000001.exr"
    color_first = meta["color_dir"] / "frame_000001.png"
    if not depth_first.is_file():
        raise FileNotFoundError(f"Missing {depth_first.name}")
    if not color_first.is_file():
        raise FileNotFoundError(f"Missing {color_first.name}")

    depth_img = _ensure_sequence_image(IMAGE_DEPTH, depth_first)
    color_img = _ensure_sequence_image(IMAGE_COLOR, color_first)
    return depth_img, color_img


def _sequence_frame_index(user: bpy.types.ImageUser, frame: int) -> int:
    """0-based index into the sequence for gl_load()."""
    return max(0, frame - user.frame_start)


def _load_sequence_frame(img: bpy.types.Image, user: bpy.types.ImageUser, frame: int) -> None:
    """Load one frame from a native SEQUENCE into img.pixels (Blender 4.2+)."""
    user.frame_current = frame
    seq_index = _sequence_frame_index(user, frame)

    # Preferred: keep source=SEQUENCE and use Blender's sequence loader + cache.
    try:
        img.gl_load(frame=seq_index)
        img.update()
        if img.has_data and img.size[0] > 0 and img.size[1] > 0:
            return
    except Exception:
        pass

    # Fallback: resolve path via ImageUser, reload single file, restore sequence root.
    first_path = _sequence_first_paths.get(img.name, img.filepath)
    frame_path = img.filepath_from_user(image_user=user)
    frame_abs = bpy.path.abspath(frame_path)
    first_abs = bpy.path.abspath(first_path)

    if frame_abs != first_abs:
        img.filepath = frame_path
        img.source = "FILE"
        img.reload()
        img.update()
        img.filepath = first_path
        img.source = "SEQUENCE"


def load_frame_images(meta: dict, frame: int) -> tuple[bpy.types.Image, bpy.types.Image]:
    frame_count = int(meta["manifest"]["frame_count"])
    depth_img, color_img = setup_sequence_images(meta)
    depth_user = _get_image_user(IMAGE_DEPTH, frame_count)
    color_user = _get_image_user(IMAGE_COLOR, frame_count)

    _load_sequence_frame(depth_img, depth_user, frame)
    _load_sequence_frame(color_img, color_user, frame)
    return depth_img, color_img


def _pixels_to_depth_array(img: bpy.types.Image):
    w, h = img.size
    if w <= 0 or h <= 0:
        raise RuntimeError("Depth image has no size — is the sequence loaded?")

    img.update()
    flat = img.pixels[:]
    n = w * h

    import numpy as np

    rgba = np.array(flat, dtype=np.float32).reshape(n, 4)
    # Kinect EXR is single-channel Z (mm). Blender usually puts it in red; TD used alpha.
    depth = rgba[:, 0]
    if depth.max() <= 0:
        depth = rgba[:, 3]
    depth = depth.reshape(h, w)
    return depth, w, h


def _pixels_to_color_array(img: bpy.types.Image):
    w, h = img.size
    img.update()
    flat = img.pixels[:]

    import numpy as np

    rgba = np.array(flat, dtype=np.float32).reshape(w * h, 4)
    rgb = (rgba[:, :3] * 255.0).astype(np.uint8).reshape(h, w, 3)
    return rgb, w, h


def _unproject_numpy(depth, color, intrinsics, subsample: int, near_mm: float, far_mm: float):
    import numpy as np

    fx = intrinsics["fx"]
    fy = intrinsics["fy"]
    cx = intrinsics["cx"]
    cy = intrinsics["cy"]
    h, w = depth.shape

    ys = np.arange(0, h, subsample)
    xs = np.arange(0, w, subsample)
    grid_y, grid_x = np.meshgrid(ys, xs, indexing="ij")
    z_mm = depth[grid_y, grid_x]

    valid = z_mm > 0
    if near_mm > 0:
        valid &= z_mm >= near_mm
    if far_mm > 0:
        valid &= z_mm <= far_mm

    px = grid_x[valid].astype(np.float64)
    py = grid_y[valid].astype(np.float64)
    z_mm_v = z_mm[valid].astype(np.float64)
    z_m = z_mm_v / 1000.0

    x_cv = (px - cx) * z_m / fx
    y_cv = (py - cy) * z_m / fy

    x_bl = x_cv
    y_bl = -y_cv
    z_bl = -z_m

    coords = np.stack([x_bl, y_bl, z_bl], axis=1)
    colors = color[grid_y[valid], grid_x[valid]]
    depth_attr = z_mm_v
    return coords, colors, depth_attr


def rebuild_cloud_data(context: bpy.types.Context) -> None:
    scene = context.scene
    settings = scene.kinect_take
    take_dir = _take_path(settings)
    if take_dir is None or not take_dir.is_dir():
        settings.status_message = "No take loaded"
        return

    meta = read_take_metadata(take_dir)
    frame = scene.frame_current
    depth_img, color_img = load_frame_images(meta, frame)

    depth_data, w, h = _pixels_to_depth_array(depth_img)
    color_data, cw, ch = _pixels_to_color_array(color_img)
    if (w, h) != (cw, ch):
        raise RuntimeError(f"Depth {w}x{h} and color {cw}x{ch} resolution mismatch")

    intrinsics = scaled_intrinsics(
        meta["calibration"]["color"],
        w,
        h,
        settings.width_scale,
    )

    cloud_data, _cloud_render = scene_setup.ensure_scene_layout(scene)

    coords, colors, depth_attr = _unproject_numpy(
        depth_data,
        color_data,
        intrinsics,
        settings.subsample,
        settings.near_mm,
        settings.far_mm,
    )
    _write_mesh_from_arrays(cloud_data, coords, colors, depth_attr, settings)

    scene_setup.apply_orbit_camera(settings)
    point_count = len(cloud_data.data.vertices)
    settings.status_message = f"Frame {frame}/{settings.frame_count} — {point_count:,} points"


def _write_mesh_from_arrays(obj, coords, colors, depth_attr, settings) -> None:
    import numpy as np

    mesh = obj.data
    mesh.clear_geometry()
    mesh.vertices.add(len(coords))
    mesh.vertices.foreach_set("co", coords.ravel())

    if len(mesh.vertices) == 0:
        mesh.update()
        return

    if not mesh.color_attributes:
        mesh.color_attributes.new(name="Cd", type="FLOAT_COLOR", domain="POINT")
    cd = mesh.color_attributes["Cd"]
    rgba = np.ones((len(colors), 4), dtype=np.float32)
    rgba[:, :3] = colors.astype(np.float32) / 255.0
    cd.data.foreach_set("color", rgba.ravel())

    if ATTR_DEPTH_MM not in mesh.attributes:
        mesh.attributes.new(name=ATTR_DEPTH_MM, type="FLOAT", domain="POINT")
    mesh.attributes[ATTR_DEPTH_MM].data.foreach_set("value", depth_attr.astype(np.float32))

    mesh.update()
    _apply_preview_display(obj, settings)

    cloud_render = scene_setup.get_cloud_render()
    if cloud_render is not None and default_render.has_default_render(cloud_render):
        default_render.sync_render_point_size(cloud_render, settings.point_size)
        default_render.finalize_cloud_render_object(cloud_render, obj)


def _apply_preview_display(obj: bpy.types.Object, settings) -> None:
    cloud_render = scene_setup.get_cloud_render()
    using_default_render = (
        cloud_render is not None and default_render.has_default_render(cloud_render)
    )

    if using_default_render and not settings.data_only:
        obj.hide_viewport = True
        obj.hide_render = True
        return

    if settings.data_only:
        obj.display_type = "WIRE"
        obj.hide_viewport = False
        obj.hide_render = True
        for mat_slot in obj.material_slots:
            if mat_slot.material:
                mat_slot.material = None
        return

    obj.display_type = "POINTS"
    obj.hide_render = False
    if hasattr(obj, "display"):
        obj.display.point_size = max(1, int(settings.point_size * 8))

    mat_name = "KinectCloudPreview"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(mat_name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()
        out = nodes.new("ShaderNodeOutputMaterial")
        emit = nodes.new("ShaderNodeEmission")
        vcol = nodes.new("ShaderNodeVertexColor")
        vcol.layer_name = "Cd"
        links.new(vcol.outputs["Color"], emit.inputs["Color"])
        links.new(emit.outputs["Emission"], out.inputs["Surface"])

    if not obj.material_slots:
        obj.data.materials.append(mat)
    else:
        obj.material_slots[0].material = mat


def apply_timeline_from_manifest(settings, manifest: dict) -> None:
    frame_count = int(manifest.get("frame_count", 1))
    fps = float(manifest.get("fps", 30))

    settings.frame_count = frame_count
    settings.loaded_take_name = manifest.get("source_filename", "")

    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = max(1, frame_count)
    scene.render.fps = int(fps)


def load_take(context: bpy.types.Context) -> None:
    settings = context.scene.kinect_take
    take_dir = _take_path(settings)
    if take_dir is None or not take_dir.is_dir():
        raise FileNotFoundError("Choose a valid take folder")

    scene = context.scene
    scene["kinect_loading_take"] = True
    try:
        meta = read_take_metadata(take_dir)
        clear_sequence_cache()
        validate_take_frames(meta)
        setup_sequence_images(meta)
        settings.take_path = str(take_dir)
        apply_timeline_from_manifest(settings, meta["manifest"])

        settings.subsample = 3
        settings.near_mm = 600.0
        settings.far_mm = 6000.0
        settings.point_size = 0.5
        settings.width_scale = 1.0

        scene_setup.ensure_scene_layout(scene)
        rebuild_cloud_data(context)
        frame_to_cloud(context)
    finally:
        scene.pop("kinect_loading_take", None)


def frame_to_cloud(context: bpy.types.Context) -> None:
    settings = context.scene.kinect_take
    obj = scene_setup.get_cloud_data()
    if obj is None or len(obj.data.vertices) == 0:
        return

    import numpy as np

    coords = np.array([v.co for v in obj.data.vertices])
    centroid = coords.mean(axis=0)
    settings.orbit_pivot_x = float(centroid[0])
    settings.orbit_pivot_y = float(centroid[1])
    settings.orbit_pivot_z = float(centroid[2])

    extent = np.linalg.norm(coords - centroid, axis=1).max()
    settings.orbit_distance = max(1.5, float(extent) * 2.5)
    scene_setup.apply_orbit_camera(settings)
